import Cart from "./Components/Cart/Cart.jsx";
import Checkout from "./Components/CheckOut/Checkout.jsx";
import Header from "./Components/Header/header";
import Meals from "./Components/Meals/Meals";
import { CartContextProvider } from "./Components/store/cartContext";
import { UserProgressContextProvider } from "./Components/store/UserProgressContext";

function App() {
  return (
    <UserProgressContextProvider>
      <CartContextProvider>
        <Header />
        <Meals />
        <Cart />
        <Checkout />
      </CartContextProvider>
    </UserProgressContextProvider>
  );
}

export default App;
