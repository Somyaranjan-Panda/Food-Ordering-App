import React, { useContext } from 'react';
import logoImg from '../../assets/logo.jpg';
import cartContext from '../store/cartContext';
import UserProgressContext from '../store/UserProgressContext';
import Button from '../UI/Button';

const header = () => {
    const cartCtx = useContext(cartContext);
    const userProgressCtx = useContext(UserProgressContext);

    const totalCartItems = cartCtx.items.reduce((totalNumberofItems, item) => {
        return totalNumberofItems + item.quantity;
    }, 0);

    function handleShowCart(){
        userProgressCtx.showCart();
    }

  return (
    <header id='main-header'>
        <div id='title'>
            <img src={logoImg} alt="Logo Image" />
            <h1>Food Zone</h1>
        </div>
        <nav>
            <Button textOnly onClick={handleShowCart}>Cart ({totalCartItems})</Button>
        </nav>
    </header>
  )
}

export default header;
